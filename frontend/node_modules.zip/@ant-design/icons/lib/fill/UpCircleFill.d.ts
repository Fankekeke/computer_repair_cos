import { IconDefinition } from '../types';
declare const UpCircleFill: IconDefinition;
export default UpCircleFill;

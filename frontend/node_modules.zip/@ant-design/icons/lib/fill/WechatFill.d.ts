import { IconDefinition } from '../types';
declare const WechatFill: IconDefinition;
export default WechatFill;

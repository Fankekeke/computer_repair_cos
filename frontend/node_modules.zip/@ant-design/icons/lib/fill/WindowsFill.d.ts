import { IconDefinition } from '../types';
declare const WindowsFill: IconDefinition;
export default WindowsFill;

import { IconDefinition } from '../types';
declare const HddFill: IconDefinition;
export default HddFill;

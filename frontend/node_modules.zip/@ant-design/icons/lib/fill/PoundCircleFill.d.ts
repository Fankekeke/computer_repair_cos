import { IconDefinition } from '../types';
declare const PoundCircleFill: IconDefinition;
export default PoundCircleFill;

import { IconDefinition } from '../types';
declare const EyeFill: IconDefinition;
export default EyeFill;

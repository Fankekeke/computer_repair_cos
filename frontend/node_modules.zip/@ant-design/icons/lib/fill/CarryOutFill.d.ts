import { IconDefinition } from '../types';
declare const CarryOutFill: IconDefinition;
export default CarryOutFill;

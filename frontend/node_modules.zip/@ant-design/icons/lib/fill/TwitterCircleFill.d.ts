import { IconDefinition } from '../types';
declare const TwitterCircleFill: IconDefinition;
export default TwitterCircleFill;

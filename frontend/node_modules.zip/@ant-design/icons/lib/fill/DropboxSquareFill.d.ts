import { IconDefinition } from '../types';
declare const DropboxSquareFill: IconDefinition;
export default DropboxSquareFill;

import { IconDefinition } from '../types';
declare const FrownFill: IconDefinition;
export default FrownFill;

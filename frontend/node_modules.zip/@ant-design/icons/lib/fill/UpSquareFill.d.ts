import { IconDefinition } from '../types';
declare const UpSquareFill: IconDefinition;
export default UpSquareFill;

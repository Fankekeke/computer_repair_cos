import { IconDefinition } from '../types';
declare const SkinFill: IconDefinition;
export default SkinFill;

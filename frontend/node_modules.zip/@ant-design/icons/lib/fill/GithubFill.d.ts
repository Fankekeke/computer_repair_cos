import { IconDefinition } from '../types';
declare const GithubFill: IconDefinition;
export default GithubFill;

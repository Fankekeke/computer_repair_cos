import { IconDefinition } from '../types';
declare const RedditSquareFill: IconDefinition;
export default RedditSquareFill;

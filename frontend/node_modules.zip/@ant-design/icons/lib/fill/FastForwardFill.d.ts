import { IconDefinition } from '../types';
declare const FastForwardFill: IconDefinition;
export default FastForwardFill;

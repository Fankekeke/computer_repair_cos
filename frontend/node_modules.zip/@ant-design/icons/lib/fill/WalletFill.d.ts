import { IconDefinition } from '../types';
declare const WalletFill: IconDefinition;
export default WalletFill;

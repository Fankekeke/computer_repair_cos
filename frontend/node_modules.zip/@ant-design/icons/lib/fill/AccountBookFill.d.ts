import { IconDefinition } from '../types';
declare const AccountBookFill: IconDefinition;
export default AccountBookFill;

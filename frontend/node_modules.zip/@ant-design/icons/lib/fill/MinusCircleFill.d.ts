import { IconDefinition } from '../types';
declare const MinusCircleFill: IconDefinition;
export default MinusCircleFill;

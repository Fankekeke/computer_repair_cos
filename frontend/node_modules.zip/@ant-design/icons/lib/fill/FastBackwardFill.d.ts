import { IconDefinition } from '../types';
declare const FastBackwardFill: IconDefinition;
export default FastBackwardFill;

import { IconDefinition } from '../types';
declare const InstagramFill: IconDefinition;
export default InstagramFill;

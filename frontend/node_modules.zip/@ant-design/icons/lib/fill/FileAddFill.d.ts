import { IconDefinition } from '../types';
declare const FileAddFill: IconDefinition;
export default FileAddFill;

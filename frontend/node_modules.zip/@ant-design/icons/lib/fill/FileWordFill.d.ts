import { IconDefinition } from '../types';
declare const FileWordFill: IconDefinition;
export default FileWordFill;

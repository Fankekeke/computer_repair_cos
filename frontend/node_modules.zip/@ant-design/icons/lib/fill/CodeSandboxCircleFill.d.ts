import { IconDefinition } from '../types';
declare const CodeSandboxCircleFill: IconDefinition;
export default CodeSandboxCircleFill;

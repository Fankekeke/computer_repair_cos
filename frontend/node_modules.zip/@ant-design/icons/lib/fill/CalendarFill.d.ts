import { IconDefinition } from '../types';
declare const CalendarFill: IconDefinition;
export default CalendarFill;

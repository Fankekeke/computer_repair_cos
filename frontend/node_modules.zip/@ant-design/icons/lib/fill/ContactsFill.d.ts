import { IconDefinition } from '../types';
declare const ContactsFill: IconDefinition;
export default ContactsFill;

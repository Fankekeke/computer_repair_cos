import { IconDefinition } from '../types';
declare const SlidersFill: IconDefinition;
export default SlidersFill;

import { IconDefinition } from '../types';
declare const ToolFill: IconDefinition;
export default ToolFill;

import { IconDefinition } from '../types';
declare const EditFill: IconDefinition;
export default EditFill;

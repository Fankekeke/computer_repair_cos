import { IconDefinition } from '../types';
declare const SettingFill: IconDefinition;
export default SettingFill;

import { IconDefinition } from '../types';
declare const HeartFill: IconDefinition;
export default HeartFill;

import { IconDefinition } from '../types';
declare const CopyFill: IconDefinition;
export default CopyFill;

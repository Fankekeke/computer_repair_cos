import { IconDefinition } from '../types';
declare const BoxPlotFill: IconDefinition;
export default BoxPlotFill;

import { IconDefinition } from '../types';
declare const FileExclamationFill: IconDefinition;
export default FileExclamationFill;

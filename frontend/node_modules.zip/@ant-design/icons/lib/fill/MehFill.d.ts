import { IconDefinition } from '../types';
declare const MehFill: IconDefinition;
export default MehFill;

import { IconDefinition } from '../types';
declare const FolderAddOutline: IconDefinition;
export default FolderAddOutline;

import { IconDefinition } from '../types';
declare const LineOutline: IconDefinition;
export default LineOutline;

import { IconDefinition } from '../types';
declare const ReloadTimeOutline: IconDefinition;
export default ReloadTimeOutline;

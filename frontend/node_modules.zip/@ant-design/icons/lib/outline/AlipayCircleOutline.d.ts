import { IconDefinition } from '../types';
declare const AlipayCircleOutline: IconDefinition;
export default AlipayCircleOutline;

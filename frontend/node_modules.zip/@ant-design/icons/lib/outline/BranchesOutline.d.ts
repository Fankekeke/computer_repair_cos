import { IconDefinition } from '../types';
declare const BranchesOutline: IconDefinition;
export default BranchesOutline;

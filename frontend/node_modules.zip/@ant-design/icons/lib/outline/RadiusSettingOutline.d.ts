import { IconDefinition } from '../types';
declare const RadiusSettingOutline: IconDefinition;
export default RadiusSettingOutline;

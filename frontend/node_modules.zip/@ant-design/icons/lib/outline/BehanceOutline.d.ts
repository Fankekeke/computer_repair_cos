import { IconDefinition } from '../types';
declare const BehanceOutline: IconDefinition;
export default BehanceOutline;

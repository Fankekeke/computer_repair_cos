import { IconDefinition } from '../types';
declare const FastForwardOutline: IconDefinition;
export default FastForwardOutline;

import { IconDefinition } from '../types';
declare const MonitorOutline: IconDefinition;
export default MonitorOutline;

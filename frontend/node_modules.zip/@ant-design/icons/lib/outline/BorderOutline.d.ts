import { IconDefinition } from '../types';
declare const BorderOutline: IconDefinition;
export default BorderOutline;

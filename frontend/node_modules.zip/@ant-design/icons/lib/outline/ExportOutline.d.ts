import { IconDefinition } from '../types';
declare const ExportOutline: IconDefinition;
export default ExportOutline;

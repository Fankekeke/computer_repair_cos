import { IconDefinition } from '../types';
declare const FileZipOutline: IconDefinition;
export default FileZipOutline;

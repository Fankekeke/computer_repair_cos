import { IconDefinition } from '../types';
declare const CaretDownOutline: IconDefinition;
export default CaretDownOutline;

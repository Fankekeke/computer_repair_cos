import { IconDefinition } from '../types';
declare const LeftCircleOutline: IconDefinition;
export default LeftCircleOutline;

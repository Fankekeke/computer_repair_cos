import { IconDefinition } from '../types';
declare const PicLeftOutline: IconDefinition;
export default PicLeftOutline;

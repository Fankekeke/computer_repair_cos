import { IconDefinition } from '../types';
declare const MrOutline: IconDefinition;
export default MrOutline;

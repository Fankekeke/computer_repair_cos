import { IconDefinition } from '../types';
declare const BorderLeftOutline: IconDefinition;
export default BorderLeftOutline;

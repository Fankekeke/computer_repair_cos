import { IconDefinition } from '../types';
declare const GooglePlusOutline: IconDefinition;
export default GooglePlusOutline;

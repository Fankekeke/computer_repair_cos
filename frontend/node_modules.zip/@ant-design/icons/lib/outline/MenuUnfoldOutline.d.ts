import { IconDefinition } from '../types';
declare const MenuUnfoldOutline: IconDefinition;
export default MenuUnfoldOutline;

import { IconDefinition } from '../types';
declare const ApartmentOutline: IconDefinition;
export default ApartmentOutline;

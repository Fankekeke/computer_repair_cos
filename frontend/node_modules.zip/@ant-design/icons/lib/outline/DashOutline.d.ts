import { IconDefinition } from '../types';
declare const DashOutline: IconDefinition;
export default DashOutline;

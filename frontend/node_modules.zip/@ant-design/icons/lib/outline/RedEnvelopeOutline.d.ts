import { IconDefinition } from '../types';
declare const RedEnvelopeOutline: IconDefinition;
export default RedEnvelopeOutline;

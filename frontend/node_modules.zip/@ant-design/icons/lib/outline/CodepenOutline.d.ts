import { IconDefinition } from '../types';
declare const CodepenOutline: IconDefinition;
export default CodepenOutline;

import { IconDefinition } from '../types';
declare const ReloadOutline: IconDefinition;
export default ReloadOutline;

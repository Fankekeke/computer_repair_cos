import { IconDefinition } from '../types';
declare const BorderHorizontalOutline: IconDefinition;
export default BorderHorizontalOutline;

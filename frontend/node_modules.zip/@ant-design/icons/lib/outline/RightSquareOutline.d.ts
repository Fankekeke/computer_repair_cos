import { IconDefinition } from '../types';
declare const RightSquareOutline: IconDefinition;
export default RightSquareOutline;

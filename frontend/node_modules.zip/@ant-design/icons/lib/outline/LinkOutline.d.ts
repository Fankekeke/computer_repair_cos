import { IconDefinition } from '../types';
declare const LinkOutline: IconDefinition;
export default LinkOutline;

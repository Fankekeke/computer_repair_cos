import { IconDefinition } from '../types';
declare const FireOutline: IconDefinition;
export default FireOutline;

import { IconDefinition } from '../types';
declare const AliyunOutline: IconDefinition;
export default AliyunOutline;

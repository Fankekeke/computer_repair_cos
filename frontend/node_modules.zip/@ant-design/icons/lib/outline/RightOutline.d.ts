import { IconDefinition } from '../types';
declare const RightOutline: IconDefinition;
export default RightOutline;

import { IconDefinition } from '../types';
declare const RiseOutline: IconDefinition;
export default RiseOutline;

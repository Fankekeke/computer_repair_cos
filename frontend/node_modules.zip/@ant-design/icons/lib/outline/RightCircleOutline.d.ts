import { IconDefinition } from '../types';
declare const RightCircleOutline: IconDefinition;
export default RightCircleOutline;

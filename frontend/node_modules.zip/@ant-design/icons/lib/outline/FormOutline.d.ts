import { IconDefinition } from '../types';
declare const FormOutline: IconDefinition;
export default FormOutline;

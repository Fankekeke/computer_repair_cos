import { IconDefinition } from '../types';
declare const RadiusBottomleftOutline: IconDefinition;
export default RadiusBottomleftOutline;

import { IconDefinition } from '../types';
declare const InstagramOutline: IconDefinition;
export default InstagramOutline;

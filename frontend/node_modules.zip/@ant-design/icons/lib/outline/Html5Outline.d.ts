import { IconDefinition } from '../types';
declare const Html5Outline: IconDefinition;
export default Html5Outline;

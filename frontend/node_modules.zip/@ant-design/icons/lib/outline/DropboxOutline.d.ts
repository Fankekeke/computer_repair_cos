import { IconDefinition } from '../types';
declare const DropboxOutline: IconDefinition;
export default DropboxOutline;

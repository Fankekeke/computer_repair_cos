import { IconDefinition } from '../types';
declare const QuestionCircleOutline: IconDefinition;
export default QuestionCircleOutline;

import { IconDefinition } from '../types';
declare const EnterOutline: IconDefinition;
export default EnterOutline;
